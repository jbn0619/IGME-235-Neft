window.onload = init;
window.onunload = saveData;
let url = "";
let options = null;
let term = "";
let favorites = [];
let results = [];
let favoriteNums = [];

function init() {
    document.querySelector("#search").onclick = getData;
    document.querySelector("#loadFavorites").onclick = loadFavorites;
    document.querySelector("#clearFavorites").onclick=clearFavorites;

    //Adding all gameseries to an selector tag in html
    url = "https://www.amiiboapi.com/api/gameseries";
    $.ajax({
        dataType: "json",
        url: url,
        data: null,
        success: addGameOptions
    });

    url = "https://www.amiiboapi.com/api/amiiboseries";
    $.ajax({
        dataType: "json",
        url: url,
        data: null,
        success: addAmiiboOptions
    });

    url = "https://www.amiiboapi.com/api/type";
    $.ajax({
        dataType: "json",
        url: url,
        data: null,
        success: addTypeOptions
    });

    document.querySelector("#searchterm").value = localStorage.getItem("searchTerm");
    favorites = JSON.parse(localStorage.getItem("favorites"));
    if (favorites == null) {
        favorites = [];
    }
}

function getData() {
    // 1 - main entry point to web service
    term = document.querySelector("#searchterm").value.trim();
    if (term != "") { //If there is a search term, serch by the character searched
        const SERVICE_URL = "https://www.amiiboapi.com/api/amiibo/?character=";
        url = SERVICE_URL;
        term = encodeURIComponent(term);
        url += term;
        $.ajax({
            dataType: "json",
            url: url,
            data: null,
            success: jsonLoaded
        });
    }
    else { //Otherwise, search through every single amiibo
        const SERVICE_URL = "https://www.amiiboapi.com/api/amiibo/";
        url = SERVICE_URL;
        $.ajax({
            dataType: "json",
            url: url,
            data: null,
            success: jsonLoaded
        });
    }
}

function addGameOptions(obj) {
    results = [];
    //Adds all unique game series to results array
    for (let x = 0; x < obj.amiibo.length; x++) {
        if (results.includes(obj.amiibo[x].name) == false) {
            results.push(obj.amiibo[x].name);
        }
    }

    //Adds all results into our selection tag
    for (let i = 0; i < results.length; i++) {
        let series = document.createElement("option");
        series.value = results[i];
        series.innerHTML = results[i];
        document.querySelector("#gameseries").appendChild(series);
    }
}

function addTypeOptions(obj) {
    results = [];
    //Adds all unique amiibo types to results array
    for (let x = 0; x < obj.amiibo.length; x++) {
        if (results.includes(obj.amiibo[x].name) == false) {
            results.push(obj.amiibo[x].name);
        }
    }

    //Adds all results into our selection tag
    for (let i = 0; i < results.length; i++) {
        let series = document.createElement("option");
        series.value = results[i];
        series.innerHTML = results[i];
        document.querySelector("#type").appendChild(series);
    }
}

function addAmiiboOptions(obj) {
    results = [];
    //Adds all unique amiibo series to results array
    for (let x = 0; x < obj.amiibo.length; x++) {
        if (results.includes(obj.amiibo[x].name) == false) {
            results.push(obj.amiibo[x].name);
        }
    }

    //Adds all results into our selection tag
    for (let i = 0; i < results.length; i++) {
        let series = document.createElement("option");
        series.value = results[i];
        series.innerHTML = results[i];
        document.querySelector("#amiiboseries").appendChild(series);
    }
}


function jsonLoaded(obj) {
    // 6 - if there are no results, print a message and return

    // 7 - if there is an array of results, loop through them
    results = obj.amiibo;
    let bigString = "";
    let gameseries = document.querySelector("#gameseries");
    let amiiboseries = document.querySelector("#amiiboseries");
    let type = document.querySelector("#type");

    //If statements for each of the possible sorting we may have to do
    if (gameseries.selectedIndex != 0 && amiiboseries.selectedIndex == 0 && type.selectedIndex == 0) {
        for (let i = 0; i < results.length; i++) {
            if (results[i].gameSeries == gameseries.options[gameseries.selectedIndex].value) { //Sort by game series
                bigString += "<div class='result'> <p>Name: "+results[i].name+"</p> <p>Game Series: " + results[i].gameSeries + "</p> <br> <p>Amiibo Series: " + results[i].amiiboSeries + "</p> <br> <p>Amiibo Type: " + results[i].type + "</p> <br>";
                bigString += "<button type='button' class='favorite' data-num='"+i+"'>Favorite</button> <br>";
                bigString += `<img src="${results[i].image}" title="${results[i].character}" /> </div>`;
            }
        }
    }
    else if (gameseries.selectedIndex == 0 && amiiboseries.selectedIndex != 0 && type.selectedIndex == 0) { //Sort by amiibo series
        for (let i = 0; i < results.length; i++) {
            if (results[i].amiiboSeries == amiiboseries.options[amiiboseries.selectedIndex].value) {
                bigString += "<div class='result'> <p>Name: "+results[i].name+"</p> <p>Game Series: " + results[i].gameSeries + "</p> <br> <p>Amiibo Series: " + results[i].amiiboSeries + "</p> <br> <p>Amiibo Type: " + results[i].type + "</p> <br>";
                bigString += "<button type='button' class='favorite' data-num='"+i+"'>Favorite</button> <br>";
                bigString += `<img src="${results[i].image}" title="${results[i].character}" /> </div>`;
            }
        }
    }
    else if (gameseries.selectedIndex == 0 && amiiboseries.selectedIndex == 0 && type.selectedIndex != 0) { //Sort by type
        for (let i = 0; i < results.length; i++) {
            if (results[i].type == type.options[type.selectedIndex].value) {
                bigString += "<div class='result'> <p>Name: "+results[i].name+"</p> <p>Game Series: " + results[i].gameSeries + "</p> <br> <p>Amiibo Series: " + results[i].amiiboSeries + "</p> <br> <p>Amiibo Type: " + results[i].type + "</p> <br>";
                bigString += "<button type='button' class='favorite' data-num='"+i+"'>Favorite</button> <br>";
                bigString += `<img src="${results[i].image}" title="${results[i].character}" /> </div>`;
            }
        }
    }
    else if (gameseries.selectedIndex != 0 && amiiboseries.selectedIndex != 0 && type.selectedIndex == 0) { //Sort by game series and amiibo series
        for (let i = 0; i < results.length; i++) {
            if (results[i].gameSeries == gameseries.options[gameseries.selectedIndex].value && results[i].amiiboSeries == amiiboseries.options[amiiboseries.selectedIndex].value) {
                bigString += "<div class='result'> <p>Name: "+results[i].name+"</p> <p>Game Series: " + results[i].gameSeries + "</p> <br> <p>Amiibo Series: " + results[i].amiiboSeries + "</p> <br> <p>Amiibo Type: " + results[i].type + "</p> <br>";
                bigString += "<button type='button' class='favorite' data-num='"+i+"'>Favorite</button> <br>";
                bigString += `<img src="${results[i].image}" title="${results[i].character}" /> </div>`;
            }
        }
    }
    else if (gameseries.selectedIndex != 0 && amiiboseries.selectedIndex == 0 && type.selectedIndex != 0) { //Sort by game series and type
        for (let i = 0; i < results.length; i++) {
            if (results[i].gameSeries == gameseries.options[gameseries.selectedIndex].value && results[i].type == type.options[type.selectedIndex].value) {
                bigString += "<div class='result'> <p>Name: "+results[i].name+"</p> <p>Game Series: " + results[i].gameSeries + "</p> <br> <p>Amiibo Series: " + results[i].amiiboSeries + "</p> <br> <p>Amiibo Type: " + results[i].type + "</p> <br>";
                bigString += "<button type='button' class='favorite' data-num='"+i+"'>Favorite</button> <br>";
                bigString += `<img src="${results[i].image}" title="${results[i].character}" /> </div>`;
            }
        }
    }
    else if (gameseries.selectedIndex == 0 && amiiboseries.selectedIndex != 0 && type.selectedIndex != 0) { //Sort by amiibo series and type
        for (let i = 0; i < results.length; i++) {
            if (results[i].amiiboSeries == amiiboseries.options[amiiboseries.selectedIndex].value && results[i].type == type.options[type.selectedIndex].value) {
                bigString += "<div class='result'> <p>Name: "+results[i].name+"</p> <p>Game Series: " + results[i].gameSeries + "</p> <br> <p>Amiibo Series: " + results[i].amiiboSeries + "</p> <br> <p>Amiibo Type: " + results[i].type + "</p> <br>";
                bigString += "<button type='button' class='favorite' data-num='"+i+"'>Favorite</button> <br>";
                bigString += `<img src="${results[i].image}" title="${results[i].character}" /> </div>`;
            }
        }
    }
    else if (gameseries.selectedIndex != 0 && amiiboseries.selectedIndex != 0 && type.selectedIndex != 0) { //Sort by all three
        for (let i = 0; i < results.length; i++) {
            if (results[i].amiiboSeries == amiiboseries.options[amiiboseries.selectedIndex].value && results[i].type == type.options[type.selectedIndex].value && results[i].gameSeries == gameseries.options[gameseries.selectedIndex].value) {
                bigString += "<div class='result'> <p>Name: "+results[i].name+"</p> <p>Game Series: " + results[i].gameSeries + "</p> <br> <p>Amiibo Series: " + results[i].amiiboSeries + "</p> <br> <p>Amiibo Type: " + results[i].type + "</p> <br>";
                bigString += "<button type='button' class='favorite' data-num='"+i+"'>Favorite</button> <br>";
                bigString += `<img src="${results[i].image}" title="${results[i].character}" /> </div>`;
            }
        }
    }
    else { //Sort by none of the options
        for (let i = 0; i < results.length; i++) {
            bigString += "<div class='result'> <p>Name: "+results[i].name+"</p> <p>Game Series: " + results[i].gameSeries + "</p> <br> <p>Amiibo Series: " + results[i].amiiboSeries + "</p> <br> <p>Amiibo Type: " + results[i].type + "</p> <br>";
            bigString += "<button type='button' class='favorite' data-num='"+i+"'>Favorite</button> <br>";
            bigString += `<img src="${results[i].image}" title="${results[i].character}" /> </div>`;
        }
    }

    // 8 - display final results to user
    if (bigString.length > 0) {
        document.querySelector("#content").innerHTML = bigString;
    }

    let favoriteButtons = document.querySelectorAll("button.favorite");
    for (let i = 0; i < results.length; i++) {
        let button = favoriteButtons[i];
        button.addEventListener("click", saveFavorites);
    }
}

function loadFavorites() { //This function loads the favorites from the localstorage of the user
    let bigString = "";
    for (let i = 0; i < favorites.length; i++) {
        bigString += "<div class='result'> <p>Name: "+favorites[i].name+"</p> <p>Game Series: " + favorites[i].gameSeries + "</p> <br> <p>Amiibo Series: " + favorites[i].amiiboSeries + "</p> <br> <p>Amiibo Type: " + favorites[i].type + "</p> <br>";
        bigString += "<button type='button' class='favorite'>Favorite</button> <br>";
        bigString += `<img src="${favorites[i].image}" title="${favorites[i].character}" /> </div>`;
    }

    if (bigString.length > 0) {
        document.querySelector("#content").innerHTML = bigString;
    }
}

function saveFavorites(e) { //Saves favorite amiibo to local storage so they can be retrieved later
    let num = e.target.dataset.num;

    num = parseInt(num);
    if (favorites.includes(results[num]) == false) {
        favorites.push(results[num]);
    }
}

function clearFavorites(){ //Clears all favorites from the favorite list
    favorites=[];
}

// This functions saves the data to the user's local browser, and uses it for new pages or returning to old ones.
function saveData() {
    // List of things to save: url, selected search options
    localStorage.setItem("url", url);
    localStorage.setItem("options", options);
    localStorage.setItem("searchTerm", term);
    localStorage.setItem("favorites", JSON.stringify(favorites));
}
